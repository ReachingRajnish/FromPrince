﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        Response.Write("<b>User name  : </b>" + User.Identity.Name + "<br>");
        Response.Write("<b>What's the authenticatin type ?  : </b>" + User.Identity.AuthenticationType + "<br>");
        Response.Write("<b>Is he authenticated ?  : </b>" + User.Identity.IsAuthenticated + "<br>");
        Response.Write("<b>Is he administrator ?  : </b>" + User.IsInRole("Administrators") + "<br>");  
    }
}

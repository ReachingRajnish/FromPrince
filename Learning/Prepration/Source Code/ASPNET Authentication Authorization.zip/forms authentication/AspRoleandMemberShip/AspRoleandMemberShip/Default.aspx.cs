﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
namespace AspRoleandMemberShip
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           


        }

        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            
            if (Membership.ValidateUser(Login1.UserName, Login1.Password))
            {
                Response.Redirect("WebForm1.aspx");
            }
        }

        protected void CreateUserWizard1_CreatedUser(object sender, EventArgs e)
        {
            
            MembershipCreateStatus status;
            Membership.CreateUser(CreateUserWizard1.UserName, 
                                CreateUserWizard1.Password, 
                                CreateUserWizard1.Email, 
                                CreateUserWizard1.Question, 
                                CreateUserWizard1.Answer,
                                true, 
                                out status);
            if (status != MembershipCreateStatus.Success)
            {
                Response.Write(status.ToString());
            }
            else
            {
                Response.Write("Created");
            }

            Roles.CreateRole("Admin");
            string[] user = new string[1];
            user[0] = "Shiv";
            Roles.AddUsersToRole(user, "Admin");
        }
    }
}

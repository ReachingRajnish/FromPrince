﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            List obj = new List();
            obj.Add(
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(DecodeFrom64(textBox1.Text));
        }
        public static string DecodeFrom64(string encodedData)
        {

            byte[] encodedDataAsBytes = System.Convert.FromBase64String(encodedData);

            string returnValue = System.Text.Encoding.ASCII.GetString(encodedDataAsBytes);

            return returnValue;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


/// <summary>
/// Summary description for Customer
/// </summary>
public class Customers
{
	public Customers()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private List<Customer> UserList()
    {
        List<Customer> listcust = new List<Customer>();

        Customer objcust = new Customer();
        objcust.CustomerID = 1;
        objcust.Username = "Shiv";
        objcust.Password = "admin";
        objcust.Role = "Admin";
        listcust.Add(objcust);

        objcust = new Customer();
        objcust.CustomerID = 2;
        objcust.Username = "Shyam";
        objcust.Password = "user";
        objcust.Role = "User";
        listcust.Add(objcust);

       


        return listcust;
    }


    private Customer CheckUser(string username, string password)
    {

      
        List<Customer> listcust = UserList();
        Customer cusTemp = new Customer();



        cusTemp = listcust.Find(delegate(Customer _cus)
        {

            if (_cus.Username == username && _cus.Password == password)
            {

                return true;

            }

            return false;

        });

        return cusTemp;


    }


    public bool AuthenticateUser(string username, string password)
    {
        try
        {
            Customer objCust = CheckUser(username, password);

            if (objCust.Username != "" && objCust.CustomerID != 0)
            {
                return true;
            }
        }
        catch
        {
            return false;
        }
        return false;
    }



    public Customer GetRoles(string username, string password)
    {


        List<Customer> listcust = UserList();
        Customer cusTemp = new Customer();



        cusTemp = listcust.Find(delegate(Customer _cus)
        {

            if (_cus.Username == username && _cus.Password == password)
            {

                return true;

            }

            return false;

        });

        return cusTemp;


    }


}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Security.Principal;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //FormsAuthentication.SetAuthCookie(objCusts.Username, false);
        //FormsAuthenticationTicket formticket = new FormsAuthenticationTicket(1, objCusts.Username, DateTime.Now, DateTime.Now.AddMinutes(30), false, objCusts.Username,FormsAuthentication.FormsCookiePath);
        //HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName,FormsAuthentication.Encrypt(formticket));
        //Response.Cookies.Add(cookie);
    }


    protected void btn_login_Click(object sender, EventArgs e)
    {
        Customer objCust = new Customer();
        bool _isvalid=false;

        _isvalid = objCust.AuthenticateUser(txtUser.Text, txtPass.Text);

        if (_isvalid == true)
        {
            Customers objCusts = new Customers();
            objCusts = objCust.CheckUser(txtUser.Text, txtPass.Text);
            
      
            FormsAuthentication.RedirectFromLoginPage(objCusts.Role, false);


            string url="";
            if (Request.QueryString["ReturnUrl"] == null)
            {
                url = "Home.aspx";

            }

            else
            {
                url = Request.QueryString["ReturnUrl"];
            }

            Response.Redirect(url);
              
            

          
            
        }
        else
        {

            lblmessage.Text = "Invalid login name or password..";
        }
       

    }
}

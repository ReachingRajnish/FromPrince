﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Customer
/// </summary>
public class Customers
{
    private int _intCustomerID;
    private string _strName;
    private string _strAddress;
    private string _strPassword;
    private string _strrole;


    public int CustomerID
    {
        get
        {
            return _intCustomerID;
        }
        set
        {
            _intCustomerID = value;
        }
    }

    public string Username
    {
        get
        {
            return _strName;
        }
        set
        {
            _strName = value;
        }
    }


    public string Address
    {
        get
        {
            return _strAddress;
        }
        set
        {
            _strAddress = value;
        }
    }


    public string Password
    {
        get
        {
            return _strPassword;
        }
        set
        {
            _strPassword = value;
        }

    }


    public string Role
    {
        get
        {
            return _strrole;
        }
        set
        {
            _strrole = value;
        }

    }




}

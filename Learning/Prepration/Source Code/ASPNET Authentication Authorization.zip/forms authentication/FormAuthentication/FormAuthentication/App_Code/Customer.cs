﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Customer
/// </summary>
public class Customer
{
	public Customer()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private List<Customers> UserList()
    {
        List<Customers> listcust = new List<Customers>();

        Customers objcust = new Customers();
        objcust.CustomerID = 1;
        objcust.Username = "admin";
        objcust.Address = "France";
        objcust.Password = "admin";
        objcust.Role = "Admin";
        listcust.Add(objcust);

        objcust = new Customers();
        objcust.CustomerID = 2;
        objcust.Username = "user";
        objcust.Address = "USA";
        objcust.Password = "user";
        objcust.Role = "User";
        listcust.Add(objcust);

       


        return listcust;
    }


    public Customers CheckUser(string username, string password)
    {

      
        List<Customers> listcust = UserList();
        Customers cusTemp = new Customers();



        cusTemp = listcust.Find(delegate(Customers _cus)
        {

            if (_cus.Username == username && _cus.Password == password)
            {

                return true;

            }

            return false;

        });

        return cusTemp;


    }


    public bool AuthenticateUser(string username, string password)
    {
        try
        {
            Customers objCust = CheckUser(username, password);

            if (objCust.Username != "" && objCust.CustomerID != 0)
            {
                return true;
            }
        }
        catch
        {
            return false;
        }
        return false;
    }

}

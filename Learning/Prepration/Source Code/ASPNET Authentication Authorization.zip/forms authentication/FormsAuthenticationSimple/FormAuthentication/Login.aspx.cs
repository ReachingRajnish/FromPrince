﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Security.Principal;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //FormsAuthentication.SetAuthCookie(objCusts.Username, false);
        //FormsAuthenticationTicket formticket = new FormsAuthenticationTicket(1, objCusts.Username, DateTime.Now, DateTime.Now.AddMinutes(30), false, objCusts.Username,FormsAuthentication.FormsCookiePath);
        //HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName,FormsAuthentication.Encrypt(formticket));
        //Response.Cookies.Add(cookie);
    }


    protected void btn_login_Click(object sender, EventArgs e)
    {

        if (FormsAuthentication.Authenticate(txtUser.Text, txtPass.Text))
        //if(// sql statement)
        {
            FormsAuthentication.RedirectFromLoginPage(txtUser.Text, true);
        }
    }
}

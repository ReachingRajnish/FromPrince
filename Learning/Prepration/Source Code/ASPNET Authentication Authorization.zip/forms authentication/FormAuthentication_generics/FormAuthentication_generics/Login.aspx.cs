﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Security.Principal;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }


    protected void btn_login_Click(object sender, EventArgs e)
    {
        Customers objCusts = new Customers();
        bool _isvalid=false;

        _isvalid = objCusts.AuthenticateUser(txtUser.Text, txtPass.Text);

        if (_isvalid == true)
        {

            Customer objCust = objCusts.GetRoles(txtUser.Text, txtPass.Text);
           
          
            FormsAuthenticationTicket formticket = new FormsAuthenticationTicket(1, objCust.Username, DateTime.Now, DateTime.Now.AddMinutes(30), false, objCust.Role);
            HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(formticket));
            Response.Cookies.Add(cookie);
            

            
            string url="";
            url = "Home.aspx";
          

            Response.Redirect(url);
              
            

          
            
        }
        else
        {

            lblmessage.Text = "Invalid login name or password..";
        }
       

    }
}

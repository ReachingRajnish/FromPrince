﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        // Declare delegate
        
        public delegate void MyDelegate();

        private void Method1()
        {
            MessageBox.Show("Method1 Invoked");
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
           // Create delegate reference
            MyDelegate myptr = null;
            
            // Point the reference to the add method
            myptr = this.Method1;

            // Invoke the method through delegate object
            myptr.Invoke();
            
        }


        public Form1()
        {


            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

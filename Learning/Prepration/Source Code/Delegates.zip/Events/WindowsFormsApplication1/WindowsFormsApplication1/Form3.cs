﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        public Form1 obj = null;
        private void Callme()
        {
            label1.Text = "Message broadcasted at " + DateTime.Now.ToString();
        }
        public Form3()
        {

            InitializeComponent();
           
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            obj.objEventCallEveryOne += Callme;
        }
    }
}

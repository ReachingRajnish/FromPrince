﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public delegate void CallEveryone();
        public event CallEveryone objEventCallEveryOne;
        Form2 obj;
        Form3 obj1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            obj = new Form2();
            obj.obj = this;

            obj1 = new Form3();
            obj1.obj = this;

            obj.Show();
            obj1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
          //objEventCallEveryOne.Invoke();
           objEventCallEveryOne();
        }
    }
}

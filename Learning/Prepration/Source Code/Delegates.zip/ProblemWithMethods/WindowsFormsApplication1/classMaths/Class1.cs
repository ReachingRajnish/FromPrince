﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace classMaths
{
    public class clsMaths
    {
        public delegate int PointerMaths(int i, int y);

        public PointerMaths getPointer(int intoperation)
        {
            PointerMaths objpointer = null;
            if (intoperation == 1)
            {
                objpointer = Add;
            }
            else if (intoperation == 2)
            {
                objpointer = Sub;
            }
            else if (intoperation == 3)
            {
                objpointer = Multi;
            }
            else if (intoperation == 4)
            {
                objpointer = Div;
            }
            return objpointer;
        }

        private int Add(int i, int y)
        {
            return i + y;
        }
        private int Sub(int i, int y)
        {
            return i - y;
        }
        private int Multi(int i, int y)
        {
            return i * y;
        }
        private int Div(int i, int y)
        {
            return i / y;
        }
    }
}

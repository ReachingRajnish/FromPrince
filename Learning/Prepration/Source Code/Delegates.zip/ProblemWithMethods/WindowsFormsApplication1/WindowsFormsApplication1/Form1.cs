﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using classMaths;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clsMaths objMath = new clsMaths();
            int intOPeration = Convert.ToInt16(textBox3.Text);
            int intNumber1 = Convert.ToInt16(textBox1.Text);
            int intNumber2 = Convert.ToInt16(textBox2.Text);
            int intResult = objMath.getPointer(intOPeration).Invoke(intNumber1,intNumber2);
            
            label1.Text = intResult.ToString();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

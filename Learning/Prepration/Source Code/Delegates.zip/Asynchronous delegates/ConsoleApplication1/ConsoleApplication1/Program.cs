﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
namespace ConsoleApplication1
{
    class Program
    {
        // define a delegate for the long operation
        delegate string PointertoHugeTask();
        static void Main(string[] args)
        {
            // create the object
            clsHugeTask objHugeTask = new clsHugeTask();

            // create the delegate
            PointertoHugeTask objPointertoHugeTask = new PointertoHugeTask(objHugeTask.DoHugeTask);

            // call the delegate asynchronously
            objPointertoHugeTask.BeginInvoke(new AsyncCallback(CallbackMethod), objPointertoHugeTask);

            // wait to exit
            Console.WriteLine("Waiting in main method to complete the delegate");
            Console.ReadLine();
        }

        static void CallbackMethod(IAsyncResult result)
        {
            // get the delegate that was used to call that
            // method
           PointertoHugeTask objPointertoHugeTask =
               (PointertoHugeTask)result.AsyncState;

            // get the return value from that method call
            string strreturnValue = objPointertoHugeTask.EndInvoke(result);

            Console.WriteLine(strreturnValue);
        }
    }

    class clsHugeTask
    {
        public string DoHugeTask()
        {
            // simulate a long operation
            Thread.Sleep(5000);
            return "Huge Task Completed at " + DateTime.Now.ToString() ;
        }
    }
}

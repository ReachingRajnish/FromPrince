﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassLibrary1;
using System.Collections;
using System.Data;
namespace ConsoleApplication1
{
    class clsSupplierDal
    {
        public DataSet Suppliers()
        {
            // This will return dataset of Supplier
            return new DataSet();
        }
    }
    class clsCustomer
    {

    }
    class clsSupplier
    {
        public string SupplierCode;
        public string SupplierName;
    }
    class Suppliers : CollectionBase
    {
        public void LoadDataset()
        {
            clsSupplierDal objDal = new clsSupplierDal();
            DataSet objDs = objDal.Suppliers();
            //foreach(DataRow obj in DataSet...)
            //{
            //    List.Add(new clsSupplier());
            //}
        }
        public void Add(clsSupplier obj)
        {
            List.Add(obj);
        }
    }
   
    class Program
    {
        static void Main(string[] args)
        {
            //Suppliers obj = new Suppliers();
            //obj.Add(
            Class1<int> obj = new Class1<int>();
             bool b = obj.Compareme(1,2);
             Class1<string> obj1 = new Class1<string>();
             bool b1 = obj1.Compareme("shiv","shiv");
             
            
             List<clsSupplier> obj2 = new List<clsSupplier>();
             //obj2.Add(new clsCustomer());
             obj2.Add(new clsSupplier());
                 
        }
    }
}

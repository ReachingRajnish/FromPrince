﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class Class1<UNNKOWDATATYPE>
    {
        
        public bool Compareme(UNNKOWDATATYPE v1, UNNKOWDATATYPE v2)
        {

            if (v1.Equals(v2))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

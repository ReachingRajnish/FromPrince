﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Assembly a = Assembly.Load("c:\\x.dll");
            //Type parameterType = a.GetType();
            MyClass objMyClass = new MyClass();
            Type parameterType = objMyClass.GetType();
            string name = parameterType.Name;
            foreach (MemberInfo objMemberInfo in parameterType.GetMembers())
            {
                Console.WriteLine(objMemberInfo.Name);

            }
            foreach (PropertyInfo objPropertyInfo in parameterType.GetProperties())
            {
                Console.WriteLine(objPropertyInfo.Name);

            }

            parameterType.InvokeMember("Display",
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.InvokeMethod | BindingFlags.Instance,
                null, objMyClass, null);

            Console.ReadLine();
        }
      
    }
    
    public class MyClass
    {

        public void Display()
        {
           
            Console.WriteLine("Hmmm MyClass");
        }
    }
}

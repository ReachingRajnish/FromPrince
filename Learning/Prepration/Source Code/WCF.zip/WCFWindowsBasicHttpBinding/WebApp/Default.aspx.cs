﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApp.localhost;
namespace WebApp
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Service1 obj = new Service1();
            obj.Credentials = System.Net.CredentialCache.DefaultCredentials;
            Response.Write(obj.GetData(1, true));
        }
    }
}

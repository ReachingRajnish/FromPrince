using System;
using System.Collections.Generic;
using System.Text;

namespace WFCClientGetCost
{
    class Program
    {
        static void Main(string[] args)
        {
            Form1 objfrm = new Form1();
            objfrm.ShowDialog();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class clsParent
    {
        public int i=0;
        private string _x;
        public string x
        {
            set
            {
                x = value;
            }
            get
            {
                return x;
            }
        }
    }
    class clsChild : clsParent
    {
        public  new  void i()
        {
            Console.WriteLine("Hey i became a method");
            
        }
        public void x()
        {
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            clsParent objParent = new clsParent();
            objParent.i = 0;
            clsChild objChild = new clsChild();
            objChild.i();
            Console.Read();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ADONET
{
    public partial class OptiMisticLocking : System.Web.UI.Page
    {
        string strConnection = "Data Source=QUESTPON-SRIZE2;Initial Catalog=Library;Integrated Security=True;pooling=true";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // force the update in optimistic
            SqlConnection objConnection = new SqlConnection(strConnection);
            objConnection.Open();
            SqlCommand objCommand = new SqlCommand("Select * from tbl_items where itemname='1001'",objConnection);
           
            DataSet objDataset = new DataSet();
            SqlDataAdapter objAdapter = new SqlDataAdapter(objCommand);
           
            objAdapter.Fill(objDataset);
           
            foreach (DataRow objrow in objDataset.Tables[0].Rows)
            {
            }
            SqlCommandBuilder objCommandBuilder = new SqlCommandBuilder(objAdapter);
            objAdapter.UpdateCommand = objCommandBuilder.GetUpdateCommand();
            objDataset.Tables[0].Rows[0][3] = "xddd";
            objAdapter.Update(objDataset);
            
            objConnection.Close();
            DataView objview = new DataView(objDataset.Tables[0], "CustomerCode='shiv'","CustomerCode", DataViewRowState.CurrentRows);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection objConnection = new SqlConnection(strConnection);
            
            objConnection.Open();
            SqlTransaction objtransaction = objConnection.BeginTransaction(System.Data.IsolationLevel.Serializable);
            SqlCommand objCommand = new SqlCommand("Select * from tbl_items where itemname='1001'", objConnection,objtransaction);
           
            DataSet objDataset = new DataSet();
            SqlDataAdapter objAdapter = new SqlDataAdapter(objCommand);

            objAdapter.Fill(objDataset);
            SqlCommandBuilder objCommandBuilder = new SqlCommandBuilder(objAdapter);
            objAdapter.UpdateCommand = objCommandBuilder.GetUpdateCommand();
            objDataset.Tables[0].Rows[0][3] = "ShivChangedtoNewValue";
            objAdapter.Update(objDataset);
            objtransaction.Commit();
            objConnection.Close();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection objConnection = new SqlConnection(strConnection);
            
            
            objConnection.Open();
            
            SqlCommand objCommand = new SqlCommand("Select * from tbl_items where itemname='1001'", objConnection);

            DataSet objDataset = new DataSet();
            
            SqlDataAdapter objAdapter = new SqlDataAdapter(objCommand);
            objAdapter.Fill(objDataset);
            
            UpdateViaStoredprocedure(objDataset);
            objConnection.Close();

        }

        private void UpdateViaStoredprocedure(DataSet objDS)
        {
           

                SqlConnection objConnection = new SqlConnection(strConnection);
                objConnection.Open();
                SqlTransaction objtran= objConnection.BeginTransaction();
                SqlCommand objCommand = new SqlCommand("UpdateTblItems", objConnection);
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.Add("@ItemName", SqlDbType.NVarChar, 50);
                objCommand.Parameters.Add("@OldTimeStamp", SqlDbType.Timestamp);
                objCommand.Parameters["@ItemName"].Value = "Changeit";
                objCommand.Parameters["@OldTimeStamp"].Value = objDS.Tables[0].Rows[0]["CurrentTimeStamp"];
                try
                {
                    objCommand.ExecuteNonQuery();
                    objtran.Commit();
                    objConnection.Close();
                }
                catch (Exception ex)
                {
                    objtran.Rollback();
                }
        }
    }
}

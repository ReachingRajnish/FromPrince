﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace ADONET
{
    public partial class _Default : System.Web.UI.Page
    {
        //string strConn = "Data Source=QUESTPON-SRIZE2;Initial Catalog=Library;Integrated Security=True";
        string strConn = ConfigurationManager.AppSettings["MyConnectionString"];
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Step 1 - Open the connection
            SqlConnection objConnection = new SqlConnection(strConn);
            objConnection.Open();
            // Step 2 - Create the command object
            SqlCommand objCommand = new SqlCommand("Select * from tbl_items",objConnection);
            SqlDataReader objReader = objCommand.ExecuteReader();
            // Step 3 :- Use the SQL reader object
            //objConnection.Close();
            while (objReader.Read())
            {
                Response.Write(objReader["AuthorName"].ToString() + "<br>");
            }
            // Step 4:- Close the connection object.
            objConnection.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            // Step 1 - Open the connection
            SqlConnection objConnection = new SqlConnection(strConn);
            objConnection.Open();
             // Step 2 - Create the command object
            SqlCommand objCommand = new SqlCommand("Select * from tbl_items",objConnection);
            // Step 3 :- Create the adapter object and attach the command object
            SqlDataAdapter objAdapter = new SqlDataAdapter(objCommand);
            // Step 4 :- Use the adapter to fill the dataset.
            DataSet objDataset = new DataSet();
            objAdapter.Fill(objDataset);
            
            objConnection.Close();
            // Step 6 :- use the dataset object
            foreach (DataRow objRow in objDataset.Tables[0].Rows)
            {
                Response.Write(objRow["AuthorName"].ToString() + "<br>");
            }

            // Step 6:- Close the connection object.
            objConnection.Close();
            //DataView objView = new DataView(objDataset.Tables[0], "AuthorName='sss'", "AuthorName", DataViewRowState.CurrentRows);
            //objDataset.Tables[0].Rows.Find(
            //objDataset.WriteXml(
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            // Step 1 - Open the connection
            SqlConnection objConnection = new SqlConnection(strConn);
            objConnection.Open();
            //SqlTransaction objtrans = objConnection.BeginTransaction();
            try
            {
                // Step 2 - Create the command object  and write your insert statments
                SqlCommand objCommand = new SqlCommand("insert into tbl_items(ItemName,Type,AuthorName,Vendor) values('12333',1,'xyz','bpb')", objConnection);

                //SqlCommand objCommand = new SqlCommand("sp_Insert", objConnection);

                //objCommand.CommandType = CommandType.StoredProcedure;
                //objCommand.Parameters.Add("@ItemName", SqlDbType.NVarChar, 10);
                //objCommand.Parameters.Add("@Type", SqlDbType.Int);
                //objCommand.Parameters.Add("@AuthorName", SqlDbType.NVarChar, 10);
                //objCommand.Parameters.Add("@VendorName", SqlDbType.NVarChar, 10);

                //objCommand.Parameters["@ItemName"].Value = "1010";

                // Step 3 :- Call execute  non query
                
                objCommand.ExecuteNonQuery();
                //objtrans.Commit();
                // Step 4:- Close the connection object.
                objConnection.Close();
            }
            catch (Exception ex)
            {
                //objtrans.Rollback();
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            // Step 1 - Open the connection
            SqlConnection objConnection = new SqlConnection(strConn);
            objConnection.Open();
            //SqlTransaction objtrans = objConnection.BeginTransaction();
            try
            {
                // Step 2 - Create the command object  and write your insert statments
                SqlCommand objCommand = new SqlCommand("insert into tbl_items(ItemName,Type,AuthorName,Vendor) values('" + TextBox1.Text + "'," + TextBox2.Text + ",'" + TextBox3.Text +  " ','" +  TextBox4.Text + "')", objConnection);

              
                // Step 3 :- Call execute  non query

                objCommand.ExecuteNonQuery();
                //objtrans.Commit();
                // Step 4:- Close the connection object.
                objConnection.Close();
            }
            catch (Exception ex)
            {
                //objtrans.Rollback();
            }
        }
    }
}

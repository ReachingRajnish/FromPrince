﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public delegate void CallEveryOne();
        public CallEveryOne ptrcall;
        public Form2 obj;
        public Form3 obj1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            obj = new Form2();
            obj.Show();
            obj1 = new Form3();

            obj1.Show();

            // inform every one

            ptrcall = null;
            // registration
            ptrcall += obj.CallMe;
            ptrcall += obj1.CallMe;
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

            
            ptrcall.Invoke();
         }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyHelloInterface;
using System.Runtime.Remoting;
namespace MyClassLibrary
{
    public class ClsHello : MarshalByRefObject, MyInterface 
    {
        public string SayHello(string strName)
        {
            return "Hello from Remoting " + strName;
        }
    }
}

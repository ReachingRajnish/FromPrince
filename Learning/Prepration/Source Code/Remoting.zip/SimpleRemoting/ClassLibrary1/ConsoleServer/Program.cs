﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using System.Runtime.Remoting;
using MyClassLibrary;
using MyHelloInterface;
using System.Reflection;
namespace ConsoleServer
{
    class Program
    {
        static void Main(string[] args)
        {
            HttpChannel objHttpChannel = new HttpChannel(1234);
            Console.WriteLine("Channel initialized");
            ChannelServices.RegisterChannel(objHttpChannel,false);
            Console.WriteLine("Channel Registered");
            RemotingConfiguration.RegisterWellKnownServiceType(typeof(ClsHello),"MySite",WellKnownObjectMode.Singleton);
            
            Console.WriteLine("Remoting Service Activated");
            Console.ReadLine();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyHelloInterface;
using System.Runtime;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using System.Reflection;

namespace ConsoleClient
{
    class Program
    {
        static void Main(string[] args)
        {
            //ClsHello obj = new ClsHello();
            //Console.WriteLine(obj.SayHello("Shiv"));
            HttpChannel objChannel = new HttpChannel();
            ChannelServices.RegisterChannel(objChannel,false);
            MyInterface iobj = (MyInterface) Activator.GetObject(typeof(MyInterface), "http://localhost:1234/MySite");
            Console.WriteLine(iobj.SayHello("Shiv"));
            Console.ReadLine();
        }
       
    }
}

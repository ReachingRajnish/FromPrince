﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SilverLightWCFService.ServiceReference1;
namespace SilverLightWCFService
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();
            Service1Client obj = new Service1Client();
            obj.GetDataCompleted += new EventHandler<GetDataCompletedEventArgs>(DisplayResults);
            obj.GetDataAsync(420);
        }
       void DisplayResults(object sender,GetDataCompletedEventArgs  e)
       {
           Mytext.Text = e.Result.ToString();
       }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Data;
namespace WCFDatabaseService
{
    // NOTE: If you change the class name "Service1" here, you must also update the reference to "Service1" in Web.config and in the associated .svc file.
    public class ServiceCustomer : IServiceCustomer
    {
        public clsCustomer getCustomer(int intCustomer)
        {
            SqlConnection objConnection = new SqlConnection();
            DataSet ObjDataset = new DataSet();
            SqlDataAdapter objAdapater = new SqlDataAdapter();
            SqlCommand objCommand = new SqlCommand("Select * from Customer where CustomerId=" + intCustomer.ToString());
            objConnection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ConnStr"].ToString();
            objConnection.Open();
            objCommand.Connection = objConnection;
            objAdapater.SelectCommand = objCommand;
            objAdapater.Fill(ObjDataset);
            clsCustomer objCustomer = new clsCustomer();
            objCustomer.CustomerCode = ObjDataset.Tables[0].Rows[0][0].ToString();
            objCustomer.Customer = ObjDataset.Tables[0].Rows[0][1].ToString();
            objConnection.Close();
            return objCustomer;
        }
    }
}

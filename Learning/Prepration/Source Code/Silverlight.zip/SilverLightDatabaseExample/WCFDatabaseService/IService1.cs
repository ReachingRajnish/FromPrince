﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WCFDatabaseService
{
    // NOTE: If you change the interface name "IService1" here, you must also update the reference to "IService1" in Web.config.
    [ServiceContract]
    public interface IServiceCustomer
    {

        [OperationContract]
        clsCustomer getCustomer(int intCustomer);
    }

    // Customer data contract
    [DataContract]
    public class clsCustomer
    {
        private string _strCustomer;
        private string _strCustomerCode;

        [DataMember]
        public string Customer
        {
            get { return _strCustomer; }
            set { _strCustomer = value; }
        }

        [DataMember]
        public string CustomerCode
        {
            get { return _strCustomerCode; }
            set { _strCustomerCode = value; }
        }
    }
}

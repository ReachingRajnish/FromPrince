﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//
using System.ComponentModel;
namespace SilverLightBinding 
{
    public class clsDate : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private int _intYear;
        private int _intAge;
        public int Year
        {
            set
            {
                _intYear = value;
                OnPropertyChanged("Year");

            }
            get
            {
                return _intYear;
            }

        }
        public int Age
        {
            set
            {
                _intAge = value;
                Year = DateTime.Now.Year - _intAge;
            }
            get
            {
                return _intAge;
            }
        }
        private void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this,
                      new PropertyChangedEventArgs(property));
            }
        }

    }
}

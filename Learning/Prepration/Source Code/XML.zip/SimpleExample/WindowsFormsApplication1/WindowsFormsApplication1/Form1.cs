﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Xml.XPath;
using System.Xml.Schema;
using System.Xml.Xsl;
using Microsoft.Xml.XQuery;
using System.Xml.Serialization;
using System.Xml.Linq;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        XmlDocument doc = new XmlDocument();
        public Form1()
        {
           

            InitializeComponent();
        }
        void doc_NodeRemoved(object sender, XmlNodeChangedEventArgs e)
        {
            MessageBox.Show("Node " + e.Node.Name + " removed successfully!");
        }

        void doc_NodeInserted(object sender, XmlNodeChangedEventArgs e)
        {
            MessageBox.Show("Node " + e.Node.Name + " added successfully!");
        }

        void doc_NodeChanged(object sender, XmlNodeChangedEventArgs e)
        {
            MessageBox.Show("Node " + e.Node.Name + " changed successfully!");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            doc.Load("c:\\Customer.xml");


            foreach (XmlNode node in doc.DocumentElement.ChildNodes)
            {
                if (node.Attributes.Count != 0)
                {
                    listBox1.Items.Add(doc.DocumentElement.Name + "=" + doc.DocumentElement.Attributes["name"].Value);
                }

                if (node.HasChildNodes)
                {
                    foreach (XmlNode childnode in node.ChildNodes)
                    {
                        listBox1.Items.Add(node.Name + " : " + childnode.InnerText + " order id : " + node.Attributes["orderid"].Value);

                    }
                }
            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            //XmlNodeList obj = doc.GetElementsByTagName(textBox1.Text);
            //foreach (XmlNode o1 in obj)
            //{
            //}
             //XmlElement obj = doc.GetElementById(textBox1.Text);
            XmlNode obj = doc.SelectSingleNode("//Customer/order[./text()='" + textBox1.Text + "']");
            MessageBox.Show(obj.Attributes["orderid"].Value);
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            doc.NodeChanged += new XmlNodeChangedEventHandler(doc_NodeChanged);
            doc.NodeInserted += new XmlNodeChangedEventHandler(doc_NodeInserted);
            doc.NodeRemoved += new XmlNodeChangedEventHandler(doc_NodeRemoved);

            // update
            XmlNode node = doc.SelectSingleNode("//Customer/order[@orderid='o001']");

            node.ChildNodes[0].InnerText = "socks";
            
            // adding new element
            XmlElement objElement = doc.CreateElement("order");
           
            XmlAttribute obAttribute = doc.CreateAttribute("orderid");
            objElement.Attributes.Append(obAttribute);
            obAttribute.Value = "o003";
            objElement.InnerText = "watch";
            doc.DocumentElement.AppendChild(objElement);
            doc.Save("c:\\x.xml");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FileStream stream = File.OpenRead("c:\\employees.xml");
            XmlTextReader reader = new XmlTextReader(stream);
            //XmlTextWriter obj1;
            
            listBox1.Items.Clear();
            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element)
                {
                    if (reader.Name == "Customer")
                    {
                        listBox1.Items.Add(reader.GetAttribute("name"));
                    }
                }
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            //axis, node test, predicate, and function
            //employees/employee[@employeeid=1] 
            //employees/employee[firstname/text()='Andrew'] 
            //employees/employee[last()] 
            //employees/employee[position()=2] 
            //employees/employee[contains(firstname,'Nancy')] 
            //employees/employee/firstname[text()] 
            XPathNavigator navigator = null;
            navigator = doc.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select(textBox2.Text);
            while (iterator.MoveNext())
            {
                MessageBox.Show(iterator.Current.OuterXml);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // <!ELEMENT employees (employee*)>
            //<!ELEMENT employee (firstname,lastname,homephone,notes)>
            //<!ELEMENT firstname (#PCDATA)>
            //<!ELEMENT lastname (#PCDATA)>
            //<!ELEMENT homephone (#PCDATA)>
            //<!ELEMENT notes (#PCDATA)>
            //<!ATTLIST employee employeeid CDATA #REQUIRED>
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add("", "c:\\Customer.xsd");
            settings.ValidationType = ValidationType.Schema;
            settings.ValidationEventHandler += new ValidationEventHandler(OnValidationError);
            XmlReader reader = XmlReader.Create("c:\\Customer.xml", settings);
            //doc.Load(reader);
            while (reader.Read())
            {
               
            }

            reader.Close();
            //doc.Load(reader);

        }

        void OnValidationError(object sender, ValidationEventArgs e)
        {
            MessageBox.Show(e.Message);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            XslCompiledTransform xslt = new XslCompiledTransform();
            xslt.Load("c:\\Customer.xslt");
            xslt.Transform("c:\\Customer.xml", "c:\\Customer.html");

        }

        private void button9_Click(object sender, EventArgs e)
        {
            XQueryNavigatorCollection objcollection = new XQueryNavigatorCollection();
            objcollection.AddNavigator("c:\\Customer.xml", "customer");
            string strQuery =@"FOR $customer IN document('customer')//customer RETURN $customer/order";
            XQueryExpression objexp = new XQueryExpression(strQuery);
            string XML = objexp.Execute(objcollection).ToXml();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee(1);
            emp.LastName = "shiv";
            emp.FirstName = "koirala";
            StringWriter writer = new StringWriter();
            XmlSerializer ser = new XmlSerializer(typeof(Employee));
            ser.Serialize(writer, emp);
            //Employee emp1 = ser.Deserialize(...)
            string xmlText = writer.ToString();
            writer.Close();

        }
        [Serializable]
        public class Employee
        {
            protected int m_ID;
            public int ID
            {
                get { return m_ID; }
            }
            public string FirstName;
            public string LastName;
            public string Position;
            public int[] Territories;
            public Employee()
            {
                m_ID = -1;
            }
            public Employee(int empID)
            {
                m_ID = empID;
            }
            public override string ToString()
            {
                return LastName + ", " + FirstName;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee(1);
            emp.LastName = "shiv";
            emp.FirstName = "koirala";

            XmlRootAttribute root = new XmlRootAttribute();
            root.ElementName = "NorthwindEmployee";
            root.Namespace = "urn:shiv-e";
            root.IsNullable = true;

            StringWriter writer = new StringWriter();
            XmlSerializer ser = new XmlSerializer(typeof(Employee), root);
            ser.Serialize(writer, emp);
            string xmlText = writer.ToString();
            writer.Close();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            XDocument xDocument =
            new XDocument(

            new XElement("BookParticipants",
            new XElement("BookParticipant",
            new XAttribute("type", "Author"),
            new XElement("FirstName", "Joe"),
            new XElement("LastName", "Rattz")),
            new XElement("BookParticipant",

            new XAttribute("type", "Editor"),
            new XElement("FirstName", "Ewan"),
            new XElement("LastName", "Buckingham"))))
            ;

            MessageBox.Show(xDocument.ToString());
            IEnumerable<XElement> elements =
            xDocument.Element("BookParticipants").Elements("BookParticipant");

            foreach (XElement element in elements)
            {
                MessageBox.Show(element.Name + "  " +  element.Value);
                
            }
           

        }

        enum ParticipantTypes
        {
            Author = 0,
            Editor
        }

        class BookParticipant
        {
            public string FirstName;
            public string LastName;
            public ParticipantTypes ParticipantType;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            BookParticipant[] bookParticipants = new[] {
            new BookParticipant {FirstName = "Joe", LastName = "Rattz",
                   ParticipantType = ParticipantTypes.Author},
            new BookParticipant {FirstName = "Ewan", LastName = "Buckingham",
                   ParticipantType = ParticipantTypes.Editor}
            };

            XElement xBookParticipants =
            new XElement("BookParticipants",
                         bookParticipants.Select(p =>
                           new XElement("BookParticipant",
                             new XAttribute("type", p.ParticipantType),
                             new XElement("FirstName", p.FirstName),
                             new XElement("LastName", p.LastName))));

           MessageBox.Show(xBookParticipants.ToString());


        }


    }
}
